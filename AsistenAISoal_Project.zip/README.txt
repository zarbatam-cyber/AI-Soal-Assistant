ASISTEN AI SOAL - PROJECT

Project Android sederhana dengan tombol izin overlay dan asisten mengambang.
AI/OCR belum terhubung; ini fondasi aplikasi belajar.

Untuk build di GitHub Actions, lihat file workflow yang diberikan terpisah.
