package com.zarbatam.asistenaI;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(40,60,40,40);
        TextView title = new TextView(this); title.setText("Asisten AI Soal\n\nBuka izin layar mengambang lalu mulai asisten."); title.setTextSize(22); box.addView(title);
        Button izin = new Button(this); izin.setText("Izinkan tampil di atas aplikasi lain"); box.addView(izin);
        Button mulai = new Button(this); mulai.setText("Mulai Asisten Mengambang"); box.addView(mulai);
        izin.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))));
        mulai.setOnClickListener(v -> { if (Settings.canDrawOverlays(this)) startService(new Intent(this, FloatingService.class)); else startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); });
        setContentView(box);
    }
}
