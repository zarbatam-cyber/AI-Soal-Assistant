package com.zarbatam.asistenaI;

import android.app.Service; import android.content.Intent; import android.graphics.Color; import android.graphics.PixelFormat; import android.os.IBinder; import android.view.*; import android.widget.*;

public class FloatingService extends Service {
    WindowManager wm; View bubble; WindowManager.LayoutParams p;
    @Override public void onCreate(){ super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); showBubble(); }
    void showBubble(){
        TextView v=new TextView(this); v.setText("AI"); v.setTextColor(Color.WHITE); v.setTextSize(18); v.setGravity(17); v.setBackgroundColor(Color.rgb(63,81,181));
        p=new WindowManager.LayoutParams(110,110,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT); p.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL; p.x=20;
        bubble=v; wm.addView(v,p); v.setOnClickListener(x->showPanel());
    }
    void showPanel(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,25,30,25); box.setBackgroundColor(Color.WHITE);
        TextView t=new TextView(this); t.setText("Asisten AI Soal"); t.setTextSize(20); box.addView(t);
        EditText q=new EditText(this); q.setHint("Ketik soal di sini..."); box.addView(q);
        Button b=new Button(this); b.setText("Kerjakan dengan AI"); box.addView(b);
        TextView ans=new TextView(this); ans.setText("Jawaban AI akan tampil di sini.\n\nVersi ini masih demo; koneksi AI/OCR dapat ditambahkan nanti."); ans.setTextSize(16); box.addView(ans);
        Button close=new Button(this); close.setText("Tutup"); box.addView(close);
        WindowManager.LayoutParams pp=new WindowManager.LayoutParams(-1,-2,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT); pp.gravity=Gravity.CENTER; wm.addView(box,pp); close.setOnClickListener(v->wm.removeView(box));
    }
    @Override public void onDestroy(){ if(bubble!=null) wm.removeView(bubble); super.onDestroy(); }
    @Override public IBinder onBind(Intent i){ return null; }
}
